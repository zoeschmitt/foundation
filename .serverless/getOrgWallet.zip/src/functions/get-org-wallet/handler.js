var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/get-org-wallet/handler.ts
var handler_exports = {};
__export(handler_exports, {
  getOrgWallet: () => getOrgWallet,
  main: () => main
});
module.exports = __toCommonJS(handler_exports);

// src/utils/handler-response.ts
var STATUS_MESSAGES = {
  [200 /* OK */]: "success" /* SUCCESS */,
  [400 /* BAD_REQUEST */]: "bad request" /* BAD_REQUEST */,
  [500 /* ERROR */]: "There's been an error processing your request, our development team has been notified." /* ERROR */,
  [404 /* NOT_FOUND */]: "not found" /* NOT_FOUND */
};
var handlerResponse = (statusCode = 200 /* OK */, body) => {
  if (body === void 0 && STATUS_MESSAGES[statusCode])
    body["message"] = STATUS_MESSAGES[statusCode];
  return {
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Methods": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    },
    statusCode,
    body: JSON.stringify(body)
  };
};

// src/services/dynamo.service.ts
var AWS = __toESM(require("aws-sdk"));
var config2 = { region: "us-east-1" };
AWS.config.update(config2);
var {
  STAGE,
  DYNAMODB_LOCAL_STAGE,
  DYNAMODB_LOCAL_ACCESS_KEY_ID,
  DYNAMODB_LOCAL_SECRET_ACCESS_KEY,
  DYNAMODB_LOCAL_ENDPOINT
} = process.env;
if (STAGE === DYNAMODB_LOCAL_STAGE) {
  config2.accessKeyId = DYNAMODB_LOCAL_ACCESS_KEY_ID;
  config2.secretAccessKey = DYNAMODB_LOCAL_SECRET_ACCESS_KEY;
  config2.endpoint = DYNAMODB_LOCAL_ENDPOINT;
}
var documentClient = new AWS.DynamoDB.DocumentClient();
var DynamoService = class {
  constructor() {
    this.getItem = async ({ key, hash, hashValue, tableName }) => {
      const params = {
        TableName: tableName,
        Key: {
          id: key
        }
      };
      if (hash) {
        params.Key[hash] = hashValue;
      }
      const results = await this.get(params);
      if (Object.keys(results).length) {
        return results;
      }
      console.error("Item does not exist");
      throw handlerResponse(400 /* BAD_REQUEST */, { id: key });
    };
    this.put = async (params) => {
      return await documentClient.put(params).promise();
    };
    this.batchCreate = async (params) => {
      return await documentClient.batchWrite(params).promise();
    };
    this.update = async (params) => {
      return await documentClient.update(params).promise();
    };
    this.query = async (params) => {
      return await documentClient.query(params).promise();
    };
    this.get = async (params) => {
      return await documentClient.get(params).promise();
    };
    this.delete = async (params) => {
      return await documentClient.delete(params).promise();
    };
  }
};

// src/utils/org/get-org-with-api-key.ts
var getOrgWithApiKey = async (headers) => {
  try {
    const apiKey = headers["x-api-key"] !== void 0 ? headers["x-api-key"] : headers["X-API-KEY"];
    const tableName = process.env.DB_TABLE;
    const params = {
      TableName: tableName,
      Key: {
        PK: `KEY#${apiKey}`,
        SK: `KEY#${apiKey}`
      }
    };
    const dynamoService = new DynamoService();
    const res = await dynamoService.get(params);
    return res.Item;
  } catch (e) {
    console.log(`Error getOrg: ${e}`);
    return null;
  }
};

// src/functions/get-org-wallet/handler.ts
var getOrgWallet = async (event, _context) => {
  const DB_TABLE = process.env.DB_TABLE;
  const dynamoService = new DynamoService();
  try {
    let org;
    if (!event.queryStringParameters || !event.queryStringParameters.orgId) {
      org = await getOrgWithApiKey(event["headers"]);
      if (org === null)
        return handlerResponse(500 /* ERROR */, {
          message: "Error authenticating API key, our team has been notiifed."
        });
    } else {
      const orgId = event.queryStringParameters.orgId;
      const params = {
        TableName: DB_TABLE,
        Key: {
          PK: `ORG#${orgId}`,
          SK: `METADATA#${orgId}`
        }
      };
      const res = await dynamoService.get(params);
      org = res.Item;
    }
    if (!org)
      return handlerResponse(500 /* ERROR */, {
        message: "Error retrieving wallet information, please try again or contact support."
      });
    const walletResponse = {
      address: org.wallet.address,
      privateKey: org.wallet.privateKey,
      mnemonic: org.wallet.mnemonic.phrase
    };
    return handlerResponse(200 /* OK */, walletResponse);
  } catch (e) {
    console.log(`getOrg error: ${e.toString()}`);
    return handlerResponse(500 /* ERROR */, {
      message: `Error - getOrg:  ${e.toString()}`
    });
  }
};
var main = getOrgWallet;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getOrgWallet,
  main
});
//# sourceMappingURL=handler.js.map
