var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/get-user-nfts/handler.ts
var handler_exports = {};
__export(handler_exports, {
  getUserNFTs: () => getUserNFTs,
  main: () => main
});
module.exports = __toCommonJS(handler_exports);

// src/utils/handler-response.ts
var STATUS_MESSAGES = {
  [200 /* OK */]: "success" /* SUCCESS */,
  [400 /* BAD_REQUEST */]: "bad request" /* BAD_REQUEST */,
  [500 /* ERROR */]: "There's been an error processing your request, our development team has been notified." /* ERROR */,
  [404 /* NOT_FOUND */]: "not found" /* NOT_FOUND */
};
var handlerResponse = (statusCode = 200 /* OK */, body) => {
  if (body === void 0 && STATUS_MESSAGES[statusCode])
    body["message"] = STATUS_MESSAGES[statusCode];
  return {
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Methods": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    },
    statusCode,
    body: JSON.stringify(body)
  };
};

// src/services/dynamo.service.ts
var AWS = __toESM(require("aws-sdk"));
var config2 = { region: "us-east-1" };
AWS.config.update(config2);
var {
  STAGE,
  DYNAMODB_LOCAL_STAGE,
  DYNAMODB_LOCAL_ACCESS_KEY_ID,
  DYNAMODB_LOCAL_SECRET_ACCESS_KEY,
  DYNAMODB_LOCAL_ENDPOINT
} = process.env;
if (STAGE === DYNAMODB_LOCAL_STAGE) {
  config2.accessKeyId = DYNAMODB_LOCAL_ACCESS_KEY_ID;
  config2.secretAccessKey = DYNAMODB_LOCAL_SECRET_ACCESS_KEY;
  config2.endpoint = DYNAMODB_LOCAL_ENDPOINT;
}
var documentClient = new AWS.DynamoDB.DocumentClient();
var DynamoService = class {
  constructor() {
    this.getItem = async ({ key, hash, hashValue, tableName }) => {
      const params = {
        TableName: tableName,
        Key: {
          id: key
        }
      };
      if (hash) {
        params.Key[hash] = hashValue;
      }
      const results = await this.get(params);
      if (Object.keys(results).length) {
        return results;
      }
      console.error("Item does not exist");
      throw handlerResponse(400 /* BAD_REQUEST */, { id: key });
    };
    this.put = async (params) => {
      return await documentClient.put(params).promise();
    };
    this.batchCreate = async (params) => {
      return await documentClient.batchWrite(params).promise();
    };
    this.update = async (params) => {
      return await documentClient.update(params).promise();
    };
    this.query = async (params) => {
      return await documentClient.query(params).promise();
    };
    this.get = async (params) => {
      return await documentClient.get(params).promise();
    };
    this.delete = async (params) => {
      return await documentClient.delete(params).promise();
    };
  }
};

// src/utils/org/get-org-with-api-key.ts
var getOrgWithApiKey = async (headers) => {
  try {
    const apiKey = headers["x-api-key"] !== void 0 ? headers["x-api-key"] : headers["X-API-KEY"];
    const tableName = process.env.DB_TABLE;
    const params = {
      TableName: tableName,
      Key: {
        PK: `KEY#${apiKey}`,
        SK: `KEY#${apiKey}`
      }
    };
    const dynamoService = new DynamoService();
    const res = await dynamoService.get(params);
    return res.Item;
  } catch (e) {
    console.log(`Error getOrg: ${e}`);
    return null;
  }
};

// src/utils/nft/nft-utils.ts
var formatNFTList = async (items) => {
  let nfts = [];
  for (let nft in items) {
    const nftResponse = await formatNFT(items[nft]);
    nfts.push(nftResponse);
  }
  return nfts;
};
var formatNFT = async (nft) => {
  const nftResponse = {
    nftId: nft.nftId,
    walletId: nft.walletId,
    network: nft.network,
    contract: nft.contract,
    tokenId: nft.tokenId,
    transactionHash: nft.transactionHash,
    filename: nft.filename,
    ipfsHash: nft.ipfsHash,
    createdAt: nft.createdAt,
    openseaURL: nft.openseaURL,
    royalties: nft.royalties,
    metadata: nft.metadata,
    isListed: nft.isListed,
    listPrice: nft.listPrice
  };
  nftResponse["nftUrl"] = `https://ipfs.io/ipfs/${nft.ipfsHash}/metadata.json`;
  return nftResponse;
};
var updateNFTPostPurchase = async (props) => {
  const { table, orgId, nftId, previousOwnerId, newOwnerId, dynamoService } = props;
  const counterParams = {
    TableName: table,
    Key: {},
    UpdateExpression: `set isListed = :isListed, walletId = :walletId`,
    ExpressionAttributeValues: {
      ":isListed": false,
      ":walletId": newOwnerId
    },
    ReturnValues: "UPDATED_NEW"
  };
  const multipleQueryUpdate = counterParams;
  const singleQueryUpdate = counterParams;
  singleQueryUpdate.Key = {
    PK: `ORG#${orgId}#NFT#${nftId}`,
    SK: `ORG#${orgId}`
  };
  console.log(singleQueryUpdate);
  await dynamoService.update(singleQueryUpdate);
  console.log(`updateNFTPostPurchase NFT singleQueryUpdate ${nftId} successfully.`);
  multipleQueryUpdate.Key = {
    PK: `ORG#${orgId}`,
    SK: `WAL#${previousOwnerId}#NFT#${nftId}`
  };
  multipleQueryUpdate["ExpressionAttributeValues"][":SK"] = `WAL#${newOwnerId}#NFT#${nftId}`;
  multipleQueryUpdate["UpdateExpression"] += `, SK = :SK`;
  console.log(multipleQueryUpdate);
  const res = await dynamoService.update(multipleQueryUpdate);
  console.log(`updateNFTPostPurchase NFT multipleQueryUpdate ${nftId} successfully.`);
  return res.Attributes;
};
var updateNFTListing = async (props) => {
  const { table, orgId, nftId, walletId, isListed, listPrice, dynamoService } = props;
  const counterParams = {
    TableName: table,
    Key: {},
    UpdateExpression: `set isListed = :isListed, listPrice = :listPrice`,
    ExpressionAttributeValues: {
      ":isListed": isListed,
      ":listPrice": listPrice
    },
    ReturnValues: "UPDATED_NEW"
  };
  const multipleQueryUpdate = counterParams;
  const singleQueryUpdate = counterParams;
  multipleQueryUpdate.Key = {
    PK: `ORG#${orgId}`,
    SK: `WAL#${walletId}#NFT#${nftId}`
  };
  console.log(multipleQueryUpdate);
  const res = await dynamoService.update(multipleQueryUpdate);
  console.log(`Updated NFT multipleQueryUpdate ${nftId} successfully.`);
  singleQueryUpdate.Key = {
    PK: `ORG#${orgId}#NFT#${nftId}`,
    SK: `ORG#${orgId}`
  };
  console.log(singleQueryUpdate);
  await dynamoService.update(singleQueryUpdate);
  console.log(`Updated NFT singleQueryUpdate ${nftId} successfully.`);
  return res.Attributes;
};
var nft_utils_default = {
  formatNFTList,
  formatNFT,
  updateNFTListing,
  updateNFTPostPurchase
};

// src/functions/get-user-nfts/handler.ts
var getUserNFTs = async (event, _context) => {
  const DB_TABLE = process.env.DB_TABLE;
  const dynamoService = new DynamoService();
  try {
    if (!event.queryStringParameters || !event.queryStringParameters.walletId)
      return handlerResponse(404 /* NOT_FOUND */, {
        message: "walletId not found in path."
      });
    const walletId = event.queryStringParameters.walletId;
    const org = await getOrgWithApiKey(event["headers"]);
    if (org === null)
      return handlerResponse(500 /* ERROR */, {
        message: "Error authenticating API key, our team has been notiifed."
      });
    const nftQuery = await dynamoService.query({
      TableName: DB_TABLE,
      KeyConditionExpression: "#PK = :PK and begins_with(#SK, :SK)",
      ExpressionAttributeNames: { "#PK": "PK", "#SK": "SK" },
      ExpressionAttributeValues: {
        ":PK": `ORG#${org.orgId}`,
        ":SK": `WAL#${walletId}`
      }
    });
    console.log(nftQuery);
    if (!nftQuery)
      return handlerResponse(404 /* NOT_FOUND */, {
        message: "Failed to find nfts, please check your request or contact support."
      });
    const nfts = await nft_utils_default.formatNFTList(nftQuery.Items);
    console.log(`getUserNFTs Finished successfully`);
    return handlerResponse(200 /* OK */, nfts);
  } catch (e) {
    console.log(`getUserNFTs error: ${e.toString()}`);
    return handlerResponse(500 /* ERROR */, {
      message: "Failed to get nfts, please check your request or contact support."
    });
  }
};
var main = getUserNFTs;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getUserNFTs,
  main
});
//# sourceMappingURL=handler.js.map
